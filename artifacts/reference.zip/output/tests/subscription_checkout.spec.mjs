import { test, expect } from "@playwright/test";
import fs from "node:fs/promises";
import path from "node:path";

const inputRoot = path.resolve(process.env.ALE_INPUT_ROOT ?? process.cwd());
const outputRoot = path.resolve(process.env.ALE_OUTPUT_ROOT ?? path.join(inputRoot, "output"));
const evidenceRoot = path.join(outputRoot, "evidence");
const reportRoot = path.join(outputRoot, "reports");
const baseURL = "http://127.0.0.1:4173";
const contract = JSON.parse(await fs.readFile(path.join(inputRoot, "policy/test_contract.json"), "utf8"));
const fixedBrowserTime = new Date(contract.fixed_browser_time);

function parseCsv(text) {
  const records = [];
  let record = [];
  let cell = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (quoted) {
      if (char === '"' && text[index + 1] === '"') {
        cell += '"';
        index += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        cell += char;
      }
    } else if (char === '"') {
      quoted = true;
    } else if (char === ",") {
      record.push(cell);
      cell = "";
    } else if (char === "\n") {
      record.push(cell.replace(/\r$/, ""));
      records.push(record);
      record = [];
      cell = "";
    } else {
      cell += char;
    }
  }
  if (cell || record.length) {
    record.push(cell.replace(/\r$/, ""));
    records.push(record);
  }
  const headers = records.shift() ?? [];
  return records
    .filter((values) => values.some((value) => value !== ""))
    .map((values) => Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""])));
}

function csvCell(value) {
  const text = String(value ?? "");
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function csvText(headers, rows) {
  return `${headers.join(",")}\n${rows
    .map((row) => headers.map((header) => csvCell(row[header])).join(","))
    .join("\n")}\n`;
}

async function exists(file) {
  try {
    await fs.access(file);
    return true;
  } catch {
    return false;
  }
}

const cases = parseCsv(await fs.readFile(path.join(inputRoot, "cases/subscription_checkout_cases.csv"), "utf8"))
  .map((row) => ({
    ...row,
    seats: Number(row.seats),
    continue_enabled: row.continue_enabled === "true",
    total_cents: Number(row.total_cents),
    intercept_count: Number(row.intercept_count),
    stale_retry_count: Number(row.stale_retry_count),
  }));
const fixtures = JSON.parse(await fs.readFile(path.join(inputRoot, "fixtures/quote_responses.json"), "utf8"));
const caseResults = [];
const networkResults = [];

test.describe.configure({ mode: "serial" });
// Evidence is written to task-defined paths, so the runner-level trace is
// disabled for this suite and the manual tracing block below owns each archive.
test.use({ trace: "off" });

test.beforeAll(async () => {
  await fs.rm(reportRoot, { recursive: true, force: true });
  await fs.rm(evidenceRoot, { recursive: true, force: true });
  await fs.mkdir(path.join(evidenceRoot, "traces"), { recursive: true });
  await fs.mkdir(path.join(evidenceRoot, "screenshots"), { recursive: true });
  await fs.mkdir(reportRoot, { recursive: true });
});

for (const item of cases) {
  test(`${item.case_id} checkout contract`, async ({ browser }) => {
    const fixture = fixtures[item.case_id];
    expect(fixture, `fixture missing for ${item.case_id}`).toBeTruthy();
    const statuses = [];
    const requestQueries = [];
    const context = await browser.newContext({
      locale: "zh-CN",
      timezoneId: "Asia/Shanghai",
      viewport: {
        width: Number(contract.viewport.width),
        height: Number(contract.viewport.height),
      },
    });
    const page = await context.newPage();
    const tracePath = path.join(evidenceRoot, "traces", `${item.case_id}.zip`);
    const screenshotPath = path.join(evidenceRoot, "screenshots", `${item.case_id}.png`);
    await context.tracing.start({
      name: item.case_id,
      title: item.case_id,
      screenshots: true,
      snapshots: true,
      sources: true,
    });

    try {
      await page.clock.setFixedTime(fixedBrowserTime);
      await page.route(contract.quote_route, async (route) => {
        requestQueries.push(Object.fromEntries(new URL(route.request().url()).searchParams));
        const statusIndex = Math.min(statuses.length, fixture.status.length - 1);
        const status = Number(fixture.status[statusIndex]);
        statuses.push(status);
        await route.fulfill({
          status,
          contentType: "application/json",
          body: JSON.stringify(fixture.body),
        });
      });

      await page.goto(`${baseURL}${item.deep_link}`);
      const planButton = page.getByTestId(`plan-${item.plan}`);
      const regionSelect = page.getByLabel("地区");
      const couponInput = page.getByLabel("优惠码");
      const studentAge = page.getByLabel("学生年龄");
      const paymentRadio = page.getByRole("radio", { name: new RegExp(`^${item.payment_method}$`, "i") });
      const statusBanner = page.getByTestId("status-banner");
      const total = page.getByTestId("total-cents");
      const continueButton = page.getByRole("button", { name: "继续" });

      await expect(planButton).toHaveAttribute("aria-pressed", "true");
      await expect(regionSelect).toHaveValue(item.region);
      await expect(couponInput).toHaveValue(item.coupon);
      if (item.student_age !== "") await expect(studentAge).toHaveValue(item.student_age);
      await expect.poll(() => statuses.length).toBe(fixture.status.length);
      if (!(await paymentRadio.isChecked())) await paymentRadio.click();
      await expect(paymentRadio).toBeChecked();
      await expect(statusBanner).toHaveAttribute("role", "status");
      await expect(statusBanner).toHaveText(item.banner_text);
      await expect(total).toHaveText(String(item.total_cents));
      if (item.continue_enabled) await expect(continueButton).toBeEnabled();
      else await expect(continueButton).toBeDisabled();
      await expect.poll(() => statuses.length).toBe(item.intercept_count);
      const finalQuery = requestQueries.at(-1);
      expect(finalQuery.plan).toBe(item.plan);
      expect(finalQuery.seats).toBe(String(item.seats));
      expect(finalQuery.region).toBe(item.region);
      expect(finalQuery.coupon ?? "").toBe(item.coupon);
      expect(finalQuery.payment).toBe(item.payment_method);
      const browserTime = await page.evaluate(() => new Date().toISOString());
      expect(browserTime).toBe(fixedBrowserTime.toISOString());

      const focusTargets = [planButton, regionSelect, paymentRadio];
      if (item.continue_enabled) focusTargets.push(continueButton);
      for (const target of focusTargets) {
        await target.focus();
        await expect(target).toBeFocused();
      }

      const actualBanner = await statusBanner.textContent();
      const actualTotal = Number(await total.textContent());
      const actualEnabled = await continueButton.isEnabled();
      await page.screenshot({ path: screenshotPath, fullPage: true });
      caseResults.push({
        case_id: item.case_id,
        final_state: fixture.body.state,
        continue_enabled: String(actualEnabled),
        total_cents: actualTotal,
        banner_text: actualBanner,
        intercept_count: statuses.length,
        browser_time: browserTime,
        focus_check_count: focusTargets.length,
        trace_file: `output/evidence/traces/${item.case_id}.zip`,
        screenshot_file: `output/evidence/screenshots/${item.case_id}.png`,
      });
      networkResults.push({
        case_id: item.case_id,
        request_pattern: contract.quote_route,
        first_status: statuses[0],
        final_status: statuses.at(-1),
        request_count: statuses.length,
        stale_retry_count: statuses.filter((status) => status === 409).length,
        final_plan: finalQuery.plan,
        final_seats: finalQuery.seats,
        final_region: finalQuery.region,
        final_coupon: finalQuery.coupon ?? "",
        final_payment: finalQuery.payment,
        served_from: "fixtures/quote_responses.json",
      });
    } finally {
      await context.tracing.stop({ path: tracePath });
      await context.close();
    }
  });
}

test.afterAll(async () => {
  caseResults.sort((left, right) => left.case_id.localeCompare(right.case_id));
  networkResults.sort((left, right) => left.case_id.localeCompare(right.case_id));
  const evidenceManifest = caseResults.map((row) => ({
    case_id: row.case_id,
    trace_file: row.trace_file,
    screenshot_file: row.screenshot_file,
    trace_label: row.final_state,
    screenshot_assertion: row.banner_text,
  }));

  await fs.writeFile(
    path.join(reportRoot, "case_results.csv"),
    csvText(
      ["case_id", "final_state", "continue_enabled", "total_cents", "banner_text", "intercept_count", "browser_time", "focus_check_count", "trace_file", "screenshot_file"],
      caseResults,
    ),
  );
  await fs.writeFile(
    path.join(reportRoot, "network_contract.csv"),
    csvText(
      ["case_id", "request_pattern", "first_status", "final_status", "request_count", "stale_retry_count", "final_plan", "final_seats", "final_region", "final_coupon", "final_payment", "served_from"],
      networkResults,
    ),
  );
  await fs.writeFile(
    path.join(reportRoot, "evidence_manifest.csv"),
    csvText(["case_id", "trace_file", "screenshot_file", "trace_label", "screenshot_assertion"], evidenceManifest),
  );

  const toOutputPath = (archivePath) => path.join(outputRoot, ...archivePath.split("/").slice(1));
  const traceChecks = await Promise.all(caseResults.map((row) => exists(toOutputPath(row.trace_file))));
  const screenshotChecks = await Promise.all(caseResults.map((row) => exists(toOutputPath(row.screenshot_file))));
  const enabledCount = caseResults.filter((row) => row.continue_enabled === "true").length;
  const controls = {
    case_count: caseResults.length,
    enabled_case_count: enabledCount,
    disabled_case_count: caseResults.length - enabledCount,
    total_intercepts: networkResults.reduce((sum, row) => sum + Number(row.request_count), 0),
    trace_zip_count: traceChecks.filter(Boolean).length,
    screenshot_count: screenshotChecks.filter(Boolean).length,
    focus_check_count: caseResults.reduce((sum, row) => sum + Number(row.focus_check_count), 0),
  };
  const sortedCaseIds = [...caseResults].map((row) => row.case_id);
  const runSummary = {
    result: "PASS",
    fixed_browser_time: contract.fixed_browser_time,
    controls,
    case_outcomes: Object.fromEntries(caseResults.map((item) => [item.case_id, item.final_state])),
    checks: {
      all_cases_have_trace_and_screenshot: traceChecks.every(Boolean) && screenshotChecks.every(Boolean),
      no_live_api_request_required: networkResults.every((row) => row.served_from === "fixtures/quote_responses.json"),
      stale_quote_case_retries_once: networkResults.every((row) => {
        const expected = cases.find((item) => item.case_id === row.case_id);
        return Number(row.stale_retry_count) === expected.stale_retry_count;
      }),
      ready_cases_have_enabled_continue: caseResults
        .filter((row) => row.final_state === "ready")
        .every((row) => row.continue_enabled === "true"),
      blocked_cases_have_disabled_continue: caseResults
        .filter((row) => row.final_state !== "ready")
        .every((row) => row.continue_enabled === "false"),
      browser_time_is_fixed: caseResults.every((row) => row.browser_time === fixedBrowserTime.toISOString()),
      reports_are_sorted_by_case_id: sortedCaseIds.join("\n") === [...sortedCaseIds].sort().join("\n"),
      network_contract_matches_fixture_file: networkResults.every((row) => {
        const expected = fixtures[row.case_id].status.map(Number);
        return Number(row.first_status) === expected[0] && Number(row.final_status) === expected.at(-1);
      }),
      final_request_matches_case: networkResults.every((row) => {
        const expected = cases.find((item) => item.case_id === row.case_id);
        return row.final_plan === expected.plan
          && Number(row.final_seats) === expected.seats
          && row.final_region === expected.region
          && row.final_coupon === expected.coupon
          && row.final_payment === expected.payment_method;
      }),
      case_results_totals_match_summary: controls.enabled_case_count + controls.disabled_case_count === controls.case_count,
      enterprise_case_requires_manual_review: cases
        .filter((item) => item.plan === "enterprise")
        .every((item) => item.expected_state === "manual_review"),
    },
  };
  if (!Object.values(runSummary.checks).every(Boolean)) runSummary.result = "FAIL";
  await fs.writeFile(path.join(reportRoot, "run_summary.json"), `${JSON.stringify(runSummary, null, 2)}\n`);
  expect(runSummary.result).toBe("PASS");
});
