import path from "node:path";
import { defineConfig, devices } from "@playwright/test";

export default defineConfig({
  testDir: "./tests",
  outputDir: path.resolve(process.cwd(), ".playwright-artifacts"),
  timeout: 30_000,
  expect: { timeout: 5_000 },
  retries: 0,
  workers: 1,
  fullyParallel: false,
  reporter: [["line"]],
  use: {
    baseURL: "http://127.0.0.1:4173",
    trace: "on",
    screenshot: "off",
    viewport: { width: 1280, height: 900 },
    timezoneId: "Asia/Shanghai",
    locale: "zh-CN",
  },
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
  webServer: {
    command: "node tools/static-server.mjs app 4173",
    cwd: process.cwd(),
    url: "http://127.0.0.1:4173/checkout.html",
    reuseExistingServer: false,
    timeout: 30_000,
  },
});
