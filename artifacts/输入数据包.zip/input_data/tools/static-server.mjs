import http from "node:http";
import fs from "node:fs/promises";
import path from "node:path";
const root = path.resolve(process.argv[2] ?? "app");
const port = Number(process.argv[3] ?? 4173);
const types = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8" };
http.createServer(async (req, res) => {
  const clean = decodeURIComponent((req.url ?? "/").split("?")[0]);
  const file = path.join(root, clean === "/" ? "checkout.html" : clean);
  if (!file.startsWith(root)) { res.writeHead(403); res.end("forbidden"); return; }
  try {
    const body = await fs.readFile(file);
    res.writeHead(200, { "content-type": types[path.extname(file)] ?? "application/octet-stream" });
    res.end(body);
  } catch {
    res.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
    res.end("not found");
  }
}).listen(port, () => console.log("checkout fixture server listening on", port));
