import { spawn } from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";

const inputRoot = path.resolve(process.cwd());
const outputRoot = path.join(inputRoot, "output");
const reportRoot = path.join(outputRoot, "reports");
const evidenceRoot = path.join(outputRoot, "evidence");
const runnerArtifactRoot = path.join(inputRoot, ".playwright-artifacts");
const testResultRoot = path.join(inputRoot, "test-results");
const npx = process.platform === "win32" ? (process.env.ComSpec ?? "cmd.exe") : "npx";
const npxArgs = process.platform === "win32"
  ? ["/d", "/s", "/c", "npx.cmd", "playwright", "test", "--config=output/playwright.config.mjs"]
  : ["playwright", "test", "--config=output/playwright.config.mjs"];

await fs.rm(reportRoot, { recursive: true, force: true });
await fs.rm(evidenceRoot, { recursive: true, force: true });
await fs.rm(runnerArtifactRoot, { recursive: true, force: true });
await fs.rm(testResultRoot, { recursive: true, force: true });

const child = spawn(
  npx,
  npxArgs,
  {
    cwd: inputRoot,
    env: {
      ...process.env,
      ALE_INPUT_ROOT: inputRoot,
      ALE_OUTPUT_ROOT: outputRoot,
    },
    stdio: "inherit",
    windowsHide: true,
  },
);

const exitCode = await new Promise((resolve, reject) => {
  child.once("error", reject);
  child.once("exit", (code) => resolve(code ?? 1));
});

if (exitCode !== 0) {
  await fs.rm(reportRoot, { recursive: true, force: true });
  await fs.rm(evidenceRoot, { recursive: true, force: true });
  await fs.rm(runnerArtifactRoot, { recursive: true, force: true });
  await fs.rm(testResultRoot, { recursive: true, force: true });
  process.exit(exitCode);
}

await fs.rm(runnerArtifactRoot, { recursive: true, force: true });
await fs.rm(testResultRoot, { recursive: true, force: true });
