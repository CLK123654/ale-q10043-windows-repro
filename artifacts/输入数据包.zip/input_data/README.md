# 订阅结账页回归材料

app目录是一套本地静态结账页。cases/subscription_checkout_cases.csv列出产品团队维护的场景，fixtures/quote_responses.json提供各场景的报价响应，policy/test_contract.json规定浏览器时间、视口和报价拦截范围。starter目录保留了当前故障测试。

在input_data目录执行npm ci和npx playwright install chromium可以准备浏览器环境。完成测试代码后，执行npm run test:e2e。tools/run-task.mjs会启动Playwright，配置中的webServer负责提供本地页面。

订单、地区、价格和报价来自本次订阅结账回归批次，客户字段已脱敏。正式运行只访问本机回环地址，不能连接线上报价服务。
