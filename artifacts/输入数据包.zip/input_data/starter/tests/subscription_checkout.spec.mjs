import { test, expect } from "@playwright/test";

test("happy path still uses brittle selectors", async ({ page }) => {
  await page.goto("/checkout.html?plan=pro");
  await page.locator(".shell button").nth(1).click();
  await page.locator("#coupon").fill("WELCOME20");
  await expect(page.locator("#continue")).toBeEnabled();
});
