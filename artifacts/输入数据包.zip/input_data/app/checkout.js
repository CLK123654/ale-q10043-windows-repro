const params = new URLSearchParams(location.search);
const state = {
  plan: params.get("plan") || "starter",
  seats: Number(params.get("seats") || 1),
  region: params.get("region") || "US",
  coupon: params.get("coupon") || "",
  payment: "card",
};
const banner = document.querySelector("[data-testid=status-banner]");
const total = document.querySelector("[data-testid=total-cents]");
const cont = document.querySelector("[data-testid=continue-checkout]");
const clock = document.querySelector("#clock");
const selectPlan = (plan) => {
  state.plan = plan;
  document.querySelectorAll("[data-testid^=plan-]").forEach((button) => button.setAttribute("aria-pressed", String(button.dataset.testid === `plan-${plan}`)));
};
const quote = async () => {
  banner.textContent = "报价中";
  const query = new URLSearchParams({ plan: state.plan, seats: String(state.seats), region: state.region, coupon: state.coupon, payment: state.payment });
  let response = await fetch(`/api/quote?${query.toString()}`);
  if (response.status === 409) response = await fetch(`/api/quote?${query.toString()}&retry=1`);
  const body = await response.json();
  banner.textContent = body.banner_text;
  total.value = String(body.total_cents);
  total.textContent = String(body.total_cents);
  cont.disabled = !body.continue_enabled;
  clock.textContent = `报价时间：${body.generated_at}`;
};
document.querySelectorAll("[data-testid^=plan-]").forEach((button) => button.addEventListener("click", () => { selectPlan(button.dataset.testid.replace("plan-", "")); quote(); }));
document.querySelector("#seats").addEventListener("input", (event) => { state.seats = Number(event.target.value || 1); quote(); });
document.querySelector("#region").addEventListener("change", (event) => { state.region = event.target.value; quote(); });
document.querySelector("#coupon").addEventListener("input", (event) => { state.coupon = event.target.value; quote(); });
document.querySelectorAll("input[name=payment]").forEach((input) => input.addEventListener("change", () => { state.payment = document.querySelector("input[name=payment]:checked").value; quote(); }));
selectPlan(state.plan);
document.querySelector("#seats").value = String(state.seats);
document.querySelector("#region").value = state.region;
document.querySelector("#coupon").value = state.coupon;
quote();
